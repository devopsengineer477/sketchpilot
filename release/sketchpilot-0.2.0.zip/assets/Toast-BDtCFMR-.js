import{c as m,r as c,j as t}from"./index-DHzGXE83.js";/**
 * @license lucide-react v1.61.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k={name:"circle-check",size:24,node:[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m16 9-5.5 5.5L8 12",key:"xofnsj"}]],aliases:["check-circle-2"]};k.node;const j=m(k);/**
 * @license lucide-react v1.61.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h={name:"info",size:24,node:[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]]};h.node;const v=m(h);/**
 * @license lucide-react v1.61.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p={name:"moon",size:24,node:[["path",{d:"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",key:"kfwtm"}]]};p.node;const E=m(p);/**
 * @license lucide-react v1.61.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x={name:"sun",size:24,node:[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]]};x.node;const T=m(x);/**
 * @license lucide-react v1.61.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f={name:"triangle-alert",size:24,node:[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]],aliases:["alert-triangle"]};f.node;const w=m(f);/**
 * @license lucide-react v1.61.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b={name:"x",size:24,node:[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]};b.node;const g=m(b),N=c.forwardRef(function({label:o,active:e=!1,className:n="",type:l="button",children:a,...r},i){return t.jsx("button",{ref:i,type:l,title:o,"aria-label":o,"aria-pressed":r["aria-pressed"]??void 0,className:`inline-flex h-8 w-8 items-center justify-center rounded-lg transition-colors ${e?"bg-pilot-100 text-pilot-700 dark:bg-pilot-900/50 dark:text-pilot-200":"text-ink-600 hover:bg-ink-100 dark:text-ink-300 dark:hover:bg-ink-800"} ${n}`,...r,children:a})});function I({open:s,title:o,description:e,onClose:n,children:l,footer:a}){const r=c.useRef(null);return c.useEffect(()=>{if(!s)return;const i=document.activeElement;r.current?.focus();const d=u=>{u.key==="Escape"&&(u.stopPropagation(),n())};return document.addEventListener("keydown",d),()=>{document.removeEventListener("keydown",d),i?.focus?.()}},[s,n]),s?t.jsx("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-ink-950/40 p-4 animate-fade-in",onMouseDown:i=>{i.target===i.currentTarget&&n()},children:t.jsxs("div",{ref:r,role:"dialog","aria-modal":"true","aria-labelledby":"dialog-title","aria-describedby":e?"dialog-description":void 0,tabIndex:-1,className:"w-full max-w-md rounded-xl border border-ink-200 bg-white p-5 shadow-panel dark:border-ink-800 dark:bg-ink-900",children:[t.jsxs("div",{className:"flex items-start justify-between gap-4",children:[t.jsxs("div",{children:[t.jsx("h2",{id:"dialog-title",className:"text-base font-semibold",children:o}),e?t.jsx("p",{id:"dialog-description",className:"mt-1 text-sm muted",children:e}):null]}),t.jsx(N,{label:"Close dialog",onClick:n,children:t.jsx(g,{size:16,"aria-hidden":!0})})]}),l?t.jsx("div",{className:"mt-4 text-sm",children:l}):null,a?t.jsx("div",{className:"mt-5 flex justify-end gap-2",children:a}):null]})}):null}let z=1;function $(){const[s,o]=c.useState([]),e=c.useRef(new Map),n=c.useCallback(a=>{o(i=>i.filter(d=>d.id!==a));const r=e.current.get(a);r&&(clearTimeout(r),e.current.delete(a))},[]),l=c.useCallback((a,r,i)=>{const d=z++;o(y=>[...y.slice(-2),{id:d,tone:a,message:r,hint:i}]);const u=setTimeout(()=>n(d),a==="error"?9e3:4e3);return e.current.set(d,u),d},[n]);return c.useEffect(()=>{const a=e.current;return()=>{a.forEach(r=>clearTimeout(r)),a.clear()}},[]),{toasts:s,push:l,dismiss:n}}const M={info:v,success:j,error:w},_={info:"border-ink-200 bg-white text-ink-800 dark:border-ink-700 dark:bg-ink-900 dark:text-ink-100",success:"border-emerald-200 bg-emerald-50 text-emerald-900 dark:border-emerald-900 dark:bg-emerald-950 dark:text-emerald-100",error:"border-red-200 bg-red-50 text-red-900 dark:border-red-900 dark:bg-red-950 dark:text-red-100"};function C({toasts:s,onDismiss:o}){return s.length===0?null:t.jsx("div",{className:"pointer-events-none fixed bottom-4 right-4 z-[60] flex w-[min(360px,calc(100vw-2rem))] flex-col gap-2",role:"region","aria-label":"Notifications",children:s.map(e=>{const n=M[e.tone];return t.jsxs("div",{role:e.tone==="error"?"alert":"status",className:`pointer-events-auto flex items-start gap-2.5 rounded-lg border p-3 text-sm shadow-panel animate-fade-in ${_[e.tone]}`,children:[t.jsx(n,{size:16,className:"mt-0.5 shrink-0","aria-hidden":!0}),t.jsxs("div",{className:"min-w-0 flex-1",children:[t.jsx("p",{className:"font-medium",children:e.message}),e.hint?t.jsx("p",{className:"mt-1 text-[13px] opacity-80",children:e.hint}):null]}),t.jsx("button",{type:"button",onClick:()=>o(e.id),"aria-label":"Dismiss notification",className:"shrink-0 rounded p-1 opacity-60 transition-opacity hover:opacity-100",children:t.jsx(g,{size:14,"aria-hidden":!0})})]},e.id)})})}export{I as D,N as I,E as M,T as S,C as T,w as a,$ as u};
